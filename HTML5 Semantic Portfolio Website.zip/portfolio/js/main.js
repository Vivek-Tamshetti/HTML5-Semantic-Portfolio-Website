document.addEventListener("DOMContentLoaded", () => {
    const yearElements = document.querySelectorAll("#year, .year");
    const currentYear = new Date().getFullYear();
    yearElements.forEach((el) => {
        el.textContent = currentYear;
    });

    const urlParams = new URLSearchParams(window.location.search);
    const subjectParam = urlParams.get("subject");
    const subjectInput = document.getElementById("subject");
    if (subjectParam && subjectInput) {
        subjectInput.value = subjectParam;
    }

    const contactForm = document.getElementById("contact-form");

    if (contactForm) {
        contactForm.addEventListener("submit", function(event) {
            event.preventDefault();

            const name = document.getElementById("name");
            const email = document.getElementById("email");
            const message = document.getElementById("message");
            const status = document.getElementById("form-status");

            if (
                name.value.trim() === "" ||
                email.value.trim() === "" ||
                message.value.trim() === ""
            ) {
                status.textContent = "Please fill in all required fields.";
                status.style.color = "#ff6b6b";
                return;
            }

            if (!email.validity.valid) {
                status.textContent = "Please enter a valid email address.";
                status.style.color = "#ff6b6b";
                email.focus();
                return;
            }

            status.style.color = "#a8f0d1";
            status.textContent = `Thank you, ${name.value.trim()}! Your message has been sent successfully. (Demo mode)`;

            contactForm.reset();
        });
    }
});
